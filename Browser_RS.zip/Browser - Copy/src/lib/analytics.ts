export function logSearchUsage(query: string) {
  console.log(`Search logged: ${query}`);
  // TODO: Send to analytics backend
}
